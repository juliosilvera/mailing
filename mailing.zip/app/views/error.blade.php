@extends('main')

@section('body')
<center>
	<h4>Usuario o Clave Incorrectos</h4>
	<br>
	<br>
	<a href="login"><img src="img/volver.gif" style="width:80px"></a>
</center>
@stop