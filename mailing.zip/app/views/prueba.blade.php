@extends('main')

@section('body')
<img src="images/mailing_opcion_4.jpg" style="width:600px">
<img src="images/check_mailing?codigo=12345" style="visibility: hidden">
@stop