@extends('main')

@section('body')
<center><h4>Productos</h4>
<form action="cargar_productos" method="post">
	
</form>
</center>

@stop